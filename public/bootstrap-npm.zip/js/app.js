import 'bootstrap/dist/js/bootstrap';
import '../sass/style.scss';
